globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/juX2Cba3YtEHto8DC2hTb/_buildManifest.js",
    "static/juX2Cba3YtEHto8DC2hTb/_ssgManifest.js",
    "static/juX2Cba3YtEHto8DC2hTb/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0wf2rmyoojkx7.js",
    "static/chunks/0if-vqkhyn-zc.js",
    "static/chunks/299ekdt-sjm6b.js",
    "static/chunks/3-cgqtdjpbipb.js",
    "static/chunks/2-urkx3cuhmdn.js",
    "static/chunks/turbopack-2vbdpsq98gus1.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
