globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/XtrEMFbSem0IkXTDxsG07/_buildManifest.js",
    "static/XtrEMFbSem0IkXTDxsG07/_ssgManifest.js",
    "static/XtrEMFbSem0IkXTDxsG07/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0wf2rmyoojkx7.js",
    "static/chunks/0if-vqkhyn-zc.js",
    "static/chunks/299ekdt-sjm6b.js",
    "static/chunks/3-cgqtdjpbipb.js",
    "static/chunks/2-urkx3cuhmdn.js",
    "static/chunks/turbopack-2vbdpsq98gus1.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
