var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/view/route.js")
R.c("server/chunks/[root-of-the-server]__13bp5gv._.js")
R.c("server/chunks/node_modules_@opentelemetry_api_build_esm_index_1jp9ij0.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/[root-of-the-server]__02_2sm-._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_view_route_actions_0kp447i.js")
R.m(421353)
module.exports=R.m(421353).exports
