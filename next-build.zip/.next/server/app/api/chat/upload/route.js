var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/upload/route.js")
R.c("server/chunks/[root-of-the-server]__0fayse-._.js")
R.c("server/chunks/node_modules_@opentelemetry_api_build_esm_index_1jp9ij0.js")
R.c("server/chunks/[root-of-the-server]__02_2sm-._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_upload_route_actions_07o3_1m.js")
R.m(912071)
module.exports=R.m(912071).exports
