var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/[id]/permissions/route.js")
R.c("server/chunks/[root-of-the-server]__0jnk275._.js")
R.c("server/chunks/node_modules_@opentelemetry_api_build_esm_index_1jp9ij0.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__02_2sm-._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/_next-internal_server_app_api_roles_[id]_permissions_route_actions_1o7arli.js")
R.m(701830)
module.exports=R.m(701830).exports
