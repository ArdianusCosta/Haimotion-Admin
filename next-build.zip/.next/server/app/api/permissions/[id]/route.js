var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/permissions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1qoctdq._.js")
R.c("server/chunks/node_modules_@opentelemetry_api_build_esm_index_1jp9ij0.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__02_2sm-._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/_next-internal_server_app_api_permissions_[id]_route_actions_1adndio.js")
R.m(900536)
module.exports=R.m(900536).exports
