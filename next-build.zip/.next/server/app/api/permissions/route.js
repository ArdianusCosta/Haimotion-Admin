var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/permissions/route.js")
R.c("server/chunks/[root-of-the-server]__1_hz5xv._.js")
R.c("server/chunks/node_modules_@opentelemetry_api_build_esm_index_1jp9ij0.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__02_2sm-._.js")
R.c("server/chunks/node_modules_next_dist_11w3z5e._.js")
R.c("server/chunks/_next-internal_server_app_api_permissions_route_actions_20z1o5w.js")
R.m(878238)
module.exports=R.m(878238).exports
