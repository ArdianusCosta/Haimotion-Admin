module.exports=[543517,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whois_route_actions_0m8rqtp.js.map