module.exports=[7999,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_file-manager_stats_route_actions_1p0me6q.js.map