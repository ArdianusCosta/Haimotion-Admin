module.exports=[668644,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_permissions_%5Bid%5D_route_actions_1adndio.js.map