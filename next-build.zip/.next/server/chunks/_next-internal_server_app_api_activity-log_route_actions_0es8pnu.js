module.exports=[513625,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_activity-log_route_actions_0es8pnu.js.map