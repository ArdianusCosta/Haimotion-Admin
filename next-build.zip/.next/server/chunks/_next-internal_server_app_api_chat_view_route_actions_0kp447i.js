module.exports=[96677,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chat_view_route_actions_0kp447i.js.map