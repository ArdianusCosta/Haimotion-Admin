module.exports=[34774,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_file-manager_shares_route_actions_1angfkm.js.map