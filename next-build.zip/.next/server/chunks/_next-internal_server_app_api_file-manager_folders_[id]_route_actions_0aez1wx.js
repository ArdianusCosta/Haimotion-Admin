module.exports=[433671,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_file-manager_folders_%5Bid%5D_route_actions_0aez1wx.js.map