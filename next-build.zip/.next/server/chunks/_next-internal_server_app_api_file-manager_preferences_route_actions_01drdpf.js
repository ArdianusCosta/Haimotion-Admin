module.exports=[52943,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_file-manager_preferences_route_actions_01drdpf.js.map