module.exports=[284656,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_livekit_token_route_actions_1jvabuc.js.map