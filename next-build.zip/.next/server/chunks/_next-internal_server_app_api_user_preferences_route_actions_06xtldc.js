module.exports=[136614,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_preferences_route_actions_06xtldc.js.map