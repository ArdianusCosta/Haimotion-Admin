module.exports=[136767,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_file-manager_folders_route_actions_1xjx-xx.js.map